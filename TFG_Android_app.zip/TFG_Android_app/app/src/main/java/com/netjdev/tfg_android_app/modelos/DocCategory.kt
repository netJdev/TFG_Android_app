package com.netjdev.tfg_android_app.modelos

data class DocCategory (
    var name: String = ""
)
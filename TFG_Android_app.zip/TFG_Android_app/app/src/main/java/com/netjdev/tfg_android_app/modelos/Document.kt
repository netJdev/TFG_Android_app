package com.netjdev.tfg_android_app.modelos

data class Document (
    var name: String = "",
    var cleanName: String = "",
    var description: String = ""
)
package com.netjdev.tfg_android_app.modelos


data class User(
    var email: String = "",
    var name: String = "",
    var surname1: String = "",
    var surname2: String = "",
    var tlf: Int = 0,
    var address: String = "",
    var num_socio: Int = 0
)
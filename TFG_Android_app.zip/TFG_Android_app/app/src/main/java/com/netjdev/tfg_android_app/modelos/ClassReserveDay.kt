package com.netjdev.tfg_android_app.modelos

data class ClassReserveDay (
    var id: String = "",
    var name: String = ""
)
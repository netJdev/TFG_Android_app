package com.netjdev.tfg_android_app.modelos

data class GroupClass(
    var id: String = "",
    var name: String = ""
)
package com.netjdev.tfg_android_app.modelos

data class ClassReserveTime(
    var id: String = "",
    var name: String = "",
    var plazas: String = ""
)